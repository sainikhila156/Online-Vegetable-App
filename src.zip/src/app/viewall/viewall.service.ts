import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Vegetables } from '../Vegetables';

@Injectable({
  providedIn: 'root'
})
export class ViewallService {

  veg_url:string= 'assets/Data/Vegetable.json'
  constructor(private http:HttpClient) { }


  viewVegetables(): Observable<Vegetables[]>{
      return this.http.get<Vegetables[]>(this.veg_url)
  }

  addToCart(cartId: number, cartPayload: any): Observable<any> {
    return this.http.post(`http://localhost:8091/cart/addtocart/${cartId}`, cartPayload);
  }


}

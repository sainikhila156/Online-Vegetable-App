import { TestBed } from '@angular/core/testing';

import { ICartServiceService } from './i-cart-service.service';

describe('ICartServiceService', () => {
  let service: ICartServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ICartServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

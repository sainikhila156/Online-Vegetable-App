import { Vegetables } from './../Vegetables';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Cart } from '../icart';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ICartServiceService } from './i-cart-service.service';
import { ToastService } from '../toast-global/toast-service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  cartForm!: FormGroup
  constructor(private icartService: ICartServiceService, private fb: FormBuilder, private toastService: ToastService) { }
  cart: Cart = new Cart()
  initialNumber = 1;
  ngOnInit(): void {
    this.getAllCart()
    //this.emptyCart()
    /* this.cartForm = this.fb.group({
      cartId : ['',Validators.required],
      custId : ['',Validators.required]
    }) */
  }
   emptyTheCart(cartId: number) {
    //this.cart = this.icartService.emptyCart()
    if (this.cart.vegetables.length === 0) {
      return this.toastService.show('Cart is Already Empty!', { classname: 'bg-danger text-light', delay: 3000 });
    }
    this.icartService.emptyCart(cartId).toPromise().then(res2 =>{
      if (res2){
        this.cart=res2;
        this.toastService.show('Cart is Emptied!', { classname: 'bg-success text-light', delay: 3000 });
      }
    })
  }

  showStandard() {
    this.toastService.show('I am a standard toast');
  }


  /* addCart(cartId:number) {
    //this.icartService.addToCart(this.cartForm.value)
    this.icartService.addToCart(cartId).toPromise().then(res3 =>{
      if (res3){
        console.log(res3);
        this.cart=res3;
      }
    })
  } */

  addCart(cartId:number) {

  }


  getAllCart() {
    this.icartService.viewAllItems().subscribe((data)=>{console.log(data);this.cart=data})
    //this.cart = this.icartService.viewAll()
  }
  increaseItemQuantity(cartId:number,vegId:number,quantity:number){
    this.icartService.increaseQuantity(cartId,vegId,this.initialNumber).toPromise().then(rese => {
      if (rese){
        this.cart=rese;
      }
    })
  }

  decreaseItemQuantity(cartId:number,vegId:number,quantity:number){
    this.icartService.decreaseQuantity(cartId,vegId,this.initialNumber).toPromise().then(rese1 => {
      if (rese1){
        this.cart=rese1;
      }
    })
  }
  removeVegetable(cartId: number,vegId:number){
    this.icartService.removeItem(cartId,vegId).toPromise().then(res =>{
      if (res){
        this.cart=res;
        this.toastService.show('Item Removed from Cart!', { classname: 'bg-success text-light', delay: 3000 });
      }
    })
  }
  /* increaseQuantity(vegId: number) {
    for (let index = 0; index < this.cart.length; index++) {
      const element = this.cart[index];
      for (let j = 0; j < this.cart[index].vegtables.length; index++) {
        const jel = this.cart[index].vegtables[j];
        if (jel.vegId === vegId) {
          jel.quantity = jel.quantity+ 1
        }
      }
    }

    console.log(vegId)
    this.getAllCart()
  }
  decreaseQuantity(vegId: number) {
    for (let index = 0; index < this.cart.length; index++) {
      const element = this.cart[index];
      for (let j = 0; j < this.cart[index].vegtables.length; index++) {
        const jel = this.cart[index].vegtables[j];
        if (jel.vegId === vegId) {
          jel.quantity = jel.quantity- 1
        }
      }
    }
    this.getAllCart()
  } */

}

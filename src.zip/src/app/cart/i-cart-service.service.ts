import { Vegetables } from './../Vegetables';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Cart } from '../icart';
@Injectable({
  providedIn: 'root'
})
export class ICartServiceService {
  cartArray:Cart[]=[]

  constructor(private http: HttpClient) { }
  public addToCart(/*cartId:number ,vegetables: Vegetables */)/* : Observable<any> */ {
    //console.log('Carttttt izzz thiissss = 'cart.cartId +' '+ cart.custId+ ' '+ cart.vegtables);
    //return this.http.post("http://localhost:8091/cart/addtocart/1");
    //this.cartArray.push(cart)
    //return this.http.post(`http://localhost:8091/cart/addtocart/${cartId}`)
    }

  emptyCart(cartId: number): Observable<any> {
    /* this.cartArray=[]
    return this.cartArray */
    return this.http.delete(`http://localhost:8091/cart/remove/${cartId}`)
  }
  /* removeAll() : Observable<any>{
    return this.http.delete("http://localhost:8091/cart/remove/1")
  } */
  public viewAllItems(): Observable<any> {
    return this.http.get("http://localhost:8091/cart/all/3")
    //return this.cartArray
  }

  removeItem(cartId:number,vegId:number): Observable<any> {

    return this.http.delete(`http://localhost:8091/cart/remove/${cartId}/${vegId}`)
  }
  increaseQuantity(cartId:number,vegId:number,quantity:number) : Observable<any>{
    return this.http.put(`http://localhost:8091/cart/updateinc/${cartId}/${vegId}/${quantity}`,{})
  }
  decreaseQuantity(cartId:number,vegId:number,quantity:number) : Observable<any>{
    return this.http.put(`http://localhost:8091/cart/updatedec/${cartId}/${vegId}/${quantity}`,{})
  }

}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { SearchComponent } from './search/search.component';
import { ViewallComponent } from './viewall/viewall.component';
import { VegetableApplicationComponent } from './vegetable-application/vegetable-application.component';

const routes: Routes = [
  {
    path : "", redirectTo : "OnlinevegetableapplicationComponent", pathMatch : "full"
  },
  {
    path : "home", component : HomeComponent
  },
  {
    path : "cart", component : CartComponent
  },
  {
    path : "viewall", component : ViewallComponent
  },
  {
    path : "search", component : SearchComponent
  },
  {
    path : "Vegetableapplication", component : VegetableApplicationComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
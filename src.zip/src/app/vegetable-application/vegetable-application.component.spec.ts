import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VegetableApplicationComponent } from './vegetable-application.component';

describe('VegetableApplicationComponent', () => {
  let component: VegetableApplicationComponent;
  let fixture: ComponentFixture<VegetableApplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VegetableApplicationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VegetableApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

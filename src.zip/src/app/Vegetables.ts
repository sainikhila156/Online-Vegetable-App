export class Vegetables {
    vegId!: number;
    name!: String
    type!: String;
    category!: String;
    price!: number;
    quantity!: number;
}
